package com.app.service;

import com.app.model.Data;

public interface PalindromeService {

	public Data findLargestPalindromeAndPersist(Data data);
}
